package com.mesacerta.app

import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.webViewClient = WebViewClient()
        val ws: WebSettings = webView.settings
        ws.javaScriptEnabled = true
        ws.domStorageEnabled = true

        // Load local assets if available
        val hasLocalIndex = assets.list("www")?.contains("index.html") ?: false
        if (hasLocalIndex) {
            webView.loadUrl("file:///android_asset/www/index.html")
        } else {
            // Fallback: if user provided a README or index, try to load it; otherwise open MesaCerta homepage (replace if needed)
            webView.loadUrl("https://www.mesacerta.com")
        }
    }
}