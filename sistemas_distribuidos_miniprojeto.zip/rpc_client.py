# rpc_client.py
# Utilitário para enviar mensagens para a fila (arquivo) usadas pelo serviço de notificações.
import sys
QUEUE_FILE = 'message_queue.log'

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Uso: python rpc_client.py "mensagem"')
        sys.exit(1)
    msg = ' '.join(sys.argv[1:])
    with open(QUEUE_FILE, 'a') as f:
        f.write(msg + '\n')
    print('Mensagem enfileirada.')
