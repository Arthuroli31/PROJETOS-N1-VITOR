# server.py
# Servidor multi-thread que recebe uma imagem, aplica filtro (reusa filter.py logic) e devolve a imagem.
import socket, threading, os, logging, struct, time
from io import BytesIO
from PIL import Image, ImageEnhance

HOST = '0.0.0.0'
PORT = 8080
NOTIFICATION_RPC_HOST = 'localhost'
NOTIFICATION_RPC_PORT = 9001

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(threadName)s] %(message)s', handlers=[
    logging.FileHandler("logs/log_server.txt"),
    logging.StreamHandler()
])

active_connections = 0
lock = threading.Lock()

def sepia_pil(img):
    width, height = img.size
    pixels = img.load()
    for py in range(height):
        for px in range(width):
            r, g, b = img.getpixel((px, py))
            tr = int(0.393 * r + 0.769 * g + 0.189 * b)
            tg = int(0.349 * r + 0.686 * g + 0.168 * b)
            tb = int(0.272 * r + 0.534 * g + 0.131 * b)
            pixels[px, py] = (min(255, tr), min(255, tg), min(255, tb))
    return img

def rpc_notify(message):
    # RPC síncrono simples: conecta ao serviço de notificações e envia uma linha
    try:
        with socket.create_connection((NOTIFICATION_RPC_HOST, NOTIFICATION_RPC_PORT), timeout=5) as s:
            s.sendall((message + '\n').encode('utf-8'))
            # opcional: esperar confirmação
            data = s.recv(1024)
            return data.decode('utf-8').strip()
    except Exception as e:
        logging.error(f'RPC falhou: {e}')
        return None

def handle_client(conn, addr):
    global active_connections
    with lock:
        active_connections += 1
    thread_name = threading.current_thread().name
    logging.info(f'Conexao de {addr}. Atendendo. Active={active_connections}')
    try:
        # protocolo simples: primeiro 8 bytes = tamanho da imagem (unsigned long long)
        raw = conn.recv(8)
        if len(raw) < 8:
            logging.warning('Tamanho inválido recebido.')
            return
        (size,) = struct.unpack('!Q', raw)
        logging.info(f'Esperando {size} bytes de imagem...')
        received = b''
        while len(received) < size:
            chunk = conn.recv(min(4096, size - len(received)))
            if not chunk:
                break
            received += chunk
        img = Image.open(BytesIO(received)).convert('RGB')
        logging.info('Imagem recebida, aplicando filtro...')
        time.sleep(0.3)
        img = sepia_pil(img)
        buf = BytesIO()
        img.save(buf, format='JPEG')
        out_bytes = buf.getvalue()
        # notificar serviço (RPC síncrono)
        rpc_resp = rpc_notify(f'Imagem processada por {addr}. tamanho={len(out_bytes)}')
        if rpc_resp:
            logging.info(f'RPC respondeu: {rpc_resp}')
        # enviar resposta: tamanho + bytes
        conn.sendall(struct.pack('!Q', len(out_bytes)))
        conn.sendall(out_bytes)
        logging.info('Resposta enviada ao cliente.')
    except Exception as e:
        logging.exception('Erro ao tratar cliente:')
    finally:
        with lock:
            active_connections -= 1
        conn.close()

def main():
    os.makedirs('logs', exist_ok=True)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((HOST, PORT))
    s.listen(5)
    logging.info(f'Servidor escutando em {HOST}:{PORT}')
    while True:
        conn, addr = s.accept()
        t = threading.Thread(target=handle_client, args=(conn, addr), daemon=True)
        t.start()

if __name__ == '__main__':
    main()
