# filter.py
# Aplica um filtro simples (tom sépia) em duas imagens em paralelo usando threads.
import sys, threading, time, logging
from PIL import Image, ImageEnhance
import os

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(threadName)s] %(message)s', handlers=[
    logging.FileHandler("logs/log_filter.txt"),
    logging.StreamHandler()
])

def sepia(img):
    # simples conversão para sépia
    width, height = img.size
    pixels = img.load()
    for py in range(height):
        for px in range(width):
            r, g, b = img.getpixel((px, py))
            tr = int(0.393 * r + 0.769 * g + 0.189 * b)
            tg = int(0.349 * r + 0.686 * g + 0.168 * b)
            tb = int(0.272 * r + 0.534 * g + 0.131 * b)
            pixels[px, py] = (min(255, tr), min(255, tg), min(255, tb))
    return img

def process_image(path, out_name):
    start = time.time()
    logging.info(f"Inicio processamento {path}")
    img = Image.open(path).convert('RGB')
    # simula processamento custoso
    time.sleep(0.5)
    img = sepia(img)
    enhancer = ImageEnhance.Contrast(img)
    img = enhancer.enhance(1.1)
    img.save(out_name)
    elapsed = time.time() - start
    logging.info(f"Fim processamento {path} -> {out_name} (tempo {elapsed:.2f}s)")

def main(a, b):
    os.makedirs('logs', exist_ok=True)
    threads = []
    t1 = threading.Thread(target=process_image, args=(a, 'imagens/result_1.jpg'), name='Worker-1')
    t2 = threading.Thread(target=process_image, args=(b, 'imagens/result_2.jpg'), name='Worker-2')
    threads.append(t1); threads.append(t2)
    t1.start(); t2.start()
    for t in threads:
        t.join()
    logging.info("Processamento paralelo concluido.")

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print('Uso: python filter.py imagem1.jpg imagem2.jpg')
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
