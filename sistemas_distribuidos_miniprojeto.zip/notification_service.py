# notification_service.py
# Serviço que aceita RPC síncrono (porta 9001) e também "consome" uma fila simples por arquivo.
import socket, threading, os, logging, time

HOST = '0.0.0.0'
PORT = 9001
QUEUE_FILE = 'message_queue.log'

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(threadName)s] %(message)s', handlers=[
    logging.FileHandler("logs/log_notification.txt"),
    logging.StreamHandler()
])

def handle_rpc(conn, addr):
    try:
        data = conn.recv(1024).decode('utf-8').strip()
        logging.info(f'RPC recebido de {addr}: {data}')
        # aqui: simula envio de notificação imediata
        resp = f'NOTIFIED: {data}'
        conn.sendall(resp.encode('utf-8'))
    except Exception as e:
        logging.exception('Erro no RPC')
    finally:
        conn.close()

def queue_consumer():
    # simula mensageria: checa arquivo periodicamente
    while True:
        if os.path.exists(QUEUE_FILE):
            with open(QUEUE_FILE, 'r') as f:
                lines = f.readlines()
            if lines:
                with open(QUEUE_FILE, 'w') as f:
                    f.truncate(0)
                for l in lines:
                    msg = l.strip()
                    logging.info(f'Consumindo mensagem da fila: {msg}')
                    # simula envio assíncrono (pode falhar e ser re-enfileirado)
                    time.sleep(0.2)
        time.sleep(1)

def main():
    os.makedirs('logs', exist_ok=True)
    threading.Thread(target=queue_consumer, daemon=True).start()
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((HOST, PORT))
    s.listen(5)
    logging.info(f'Servico de notificacoes escutando em {HOST}:{PORT}')
    while True:
        conn, addr = s.accept()
        threading.Thread(target=handle_rpc, args=(conn, addr), daemon=True).start()

if __name__ == '__main__':
    main()
