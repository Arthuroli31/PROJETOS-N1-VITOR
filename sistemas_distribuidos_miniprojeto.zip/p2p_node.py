# p2p_node.py
# Simples nó P2P: escuta em uma porta e pode conectar a peers. Usa threads para lidar com conexões.
import socket, threading, argparse, time
from pathlib import Path

def peer_server(port, node_id):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(('0.0.0.0', port))
    s.listen(5)
    print(f'[{node_id}] Escutando em {port}')
    while True:
        conn, addr = s.accept()
        threading.Thread(target=handle_peer, args=(conn, addr, node_id), daemon=True).start()

def handle_peer(conn, addr, node_id):
    try:
        data = conn.recv(1024).decode('utf-8').strip()
        print(f'[{node_id}] Mensagem recebida de {addr}: {data}')
        resp = f'Hello from Node {node_id}!'
        conn.sendall(resp.encode('utf-8'))
    finally:
        conn.close()

def connect_to_peer(peer_addr, port, node_id):
    try:
        with socket.create_connection((peer_addr, port), timeout=5) as s:
            s.sendall(f'Hi from {node_id}'.encode('utf-8'))
            data = s.recv(1024).decode('utf-8')
            print(f'[{node_id}] Resposta de {peer_addr}:{port} -> {data}')
    except Exception as e:
        print(f'[{node_id}] Falha ao conectar em {peer_addr}:{port}: {e}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--peer', type=str, help='peer host:port', default=None)
    parser.add_argument('--id', type=str, default='X')
    args = parser.parse_args()
    threading.Thread(target=peer_server, args=(args.port, args.id), daemon=True).start()
    time.sleep(0.5)
    if args.peer:
        host, port = args.peer.split(':')
        connect_to_peer(host, int(port), args.id)
    # mantém o processo vivo
    while True:
        time.sleep(1)
