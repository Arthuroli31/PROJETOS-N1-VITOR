#!/bin/bash
# Script simples para iniciar notification_service, server e um cliente de exemplo (Linux/macOS)
echo "Iniciando notification_service (9001)..."
python3 notification_service.py & sleep 0.5
echo "Iniciando server (8080)..."
python3 server.py & sleep 0.5
echo "Enfileirando uma mensagem de teste..."
python3 rpc_client.py "Teste de fila: pedido recebido" 
echo "Pronto. Em outro terminal rode: python3 client.py imagens/detetive_pikachu.jpg"
