# Sistemas Distribuídos - Miniprojeto (Entrega)

Conteúdo:
- Parte 1: filtro de imagens com paralelismo (filter.py)
- Parte 2: cliente-servidor multi-thread (server.py, client.py)
- Parte 2 (P2P): p2p_node.py
- Parte 3: Notificações e serviços simulados (notification_service.py, rpc_client.py)
- run_all.sh: script para iniciar serviços (Linux/macOS)
- imagens/: pasta com placeholders (detetive_pikachu.jpg e outra.jpg) - substitua pelas imagens reais
- logs/: pasta onde os logs serão gravados em execução

Instruções rápidas:
1. Instale dependências:
   ```bash
   python3 -m pip install pillow
   ```
2. Para testar o filtro (Parte 1):
   ```bash
   python3 filter.py imagens/detetive_pikachu.jpg imagens/outra.jpg
   ```
   Isso processa as duas imagens em paralelo e gera imagens/result_*.jpg e logs/log_filter.txt
3. Para iniciar o serviço de notificações (RPC + fila simples por arquivo):
   ```bash
   python3 notification_service.py
   ```
4. Inicie o servidor (escuta na porta 8080) em outro terminal:
   ```bash
   python3 server.py
   ```
5. Execute um cliente que envia uma imagem ao servidor:
   ```bash
   python3 client.py imagens/detetive_pikachu.jpg
   ```
6. Para testar P2P, abra dois terminais e execute:
   ```bash
   python3 p2p_node.py --port 10001 --id A
   python3 p2p_node.py --port 10002 --id B --peer localhost:10001
   ```

Observações:
- Os scripts são uma implementação didática para fins acadêmicos; ajustes podem ser feitos para robustez.
- Troque os arquivos de imagem placeholder por imagens reais (ex: Detective Pikachu).
