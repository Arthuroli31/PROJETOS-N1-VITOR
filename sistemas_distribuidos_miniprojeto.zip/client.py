# client.py
# Cliente simples que conecta ao server.py e envia uma imagem. Recebe imagem processada.
import socket, sys, struct, time
from pathlib import Path

SERVER = ('localhost', 8080)

def send_image(path):
    data = Path(path).read_bytes()
    with socket.create_connection(SERVER, timeout=10) as s:
        s.sendall(struct.pack('!Q', len(data)))
        s.sendall(data)
        # esperar resposta
        raw = s.recv(8)
        if len(raw) < 8:
            print('Resposta inválida do servidor.')
            return
        (size,) = struct.unpack('!Q', raw)
        received = b''
        while len(received) < size:
            chunk = s.recv(min(4096, size - len(received)))
            if not chunk:
                break
            received += chunk
        out_path = 'imagens/result_from_server.jpg'
        Path(out_path).write_bytes(received)
        print(f'Imagem processada salva em {out_path}')

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('Uso: python client.py imagens/file.jpg')
        sys.exit(1)
    send_image(sys.argv[1])
